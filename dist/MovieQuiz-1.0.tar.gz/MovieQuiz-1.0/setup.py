﻿from distutils.core import setup

setup(
    name='MovieQuiz',
    version='1.0',
    py_modules=[
        'API_Key', 'ChatGPT', 'Map', 'MovieQuery', 'MovieQuiz', 'teller', 'spam'
    ],
)
