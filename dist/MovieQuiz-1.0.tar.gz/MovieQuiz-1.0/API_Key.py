Tmdb_api_key = "7dd451947ac9f89cc2c61f8dce323beb" # My_API_Key
openai_api_key = "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"
theater_api_key = "2f8525d6f25b47e7b273b373a2598da3"
telegram_key = "6071626513:AAFf_TqmbyMwO9NwWqAzRNuh7l3c5krhWC4"
telegram_my_id = "6257269899"
